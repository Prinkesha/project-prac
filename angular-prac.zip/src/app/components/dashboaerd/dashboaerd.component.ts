import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboaerd',
  templateUrl: './dashboaerd.component.html',
  styleUrls: ['./dashboaerd.component.scss']
})
export class DashboaerdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
