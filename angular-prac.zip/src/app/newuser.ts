interface newuser {
    id?: number;
    Name: string;
    Address: string;
    Contact: number;
    OrderNumber: number;
  }