import { Directive } from '@angular/core';

@Directive({
  selector: '[appCardItem]'
})
export class CardItemDirective {

  constructor() { }

}
