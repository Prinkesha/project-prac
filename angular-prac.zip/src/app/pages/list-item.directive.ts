import { Directive } from '@angular/core';

@Directive({
  selector: '[appListItem]'
})
export class ListItemDirective {

  constructor() { }

}
