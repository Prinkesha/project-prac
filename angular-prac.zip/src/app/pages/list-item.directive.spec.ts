import { ListItemDirective } from './list-item.directive';

describe('ListItemDirective', () => {
  it('should create an instance', () => {
    const directive = new ListItemDirective();
    expect(directive).toBeTruthy();
  });
});
