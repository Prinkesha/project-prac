import { CardItemDirective } from './card-item.directive';

describe('CardItemDirective', () => {
  it('should create an instance', () => {
    const directive = new CardItemDirective();
    expect(directive).toBeTruthy();
  });
});
