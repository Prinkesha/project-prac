export const environment = {
  production: true,
  apiEndPoint : 'https://fakestoreapi.com/users'
};
